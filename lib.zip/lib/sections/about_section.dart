import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/portfolio_data.dart';
import '../widgets/common_widgets.dart';

class AboutSection extends StatelessWidget {
  const AboutSection({super.key});

  static const _heading = Color(0xFFE8E8E8);
  static const _body = Color(0xFFA0A0A0);
  static const _muted = Color(0xFF787878);
  static const _accent = Color(0xFF58E6A0);
  static const _cardBg = Color(0xFF1A1A2E);
  static const _border = Color(0xFF2A2A3E);
  static const _bg = Color(0xFF0F0F1A);

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final isMobile = w < 900;
    final px = isMobile ? 20.0 : w < 1200 ? 48.0 : 80.0;

    return Container(
      width: double.infinity,
      color: _bg,
      padding: EdgeInsets.symmetric(horizontal: px, vertical: isMobile ? 64 : 110),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1180),
          child: isMobile
              ? Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _buildPhoto(280),
            const SizedBox(height: 20),
            _buildToolkit(),
            const SizedBox(height: 48),
            _buildText(isMobile),
          ])
              : Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(width: w < 1200 ? 360 : 440, child: _buildVisual()),
            SizedBox(width: w < 1200 ? 48 : 80),
            Expanded(child: _buildText(isMobile)),
          ]),
        ),
      ),
    );
  }

  Widget _buildVisual() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(
        height: 480,
        child: Stack(clipBehavior: Clip.none, children: [
          Positioned(top: -14, left: 20, child: Container(
            width: 40, height: 3,
            decoration: BoxDecoration(color: _accent.withOpacity(0.5), borderRadius: BorderRadius.circular(2)),
          )),
          Positioned(top: 0, left: 0, right: 40, bottom: 60, child: _buildPhoto(null)),
          const Positioned(bottom: 8, right: 0, child: _FloatingCard(
            imageUrl: 'https://img.icons8.com/color/96/flutter.png',
            title: '10+ Projects',
            subtitle: 'Shipped & Delivered',
          )),
        ]),
      ),
      const SizedBox(height: 28),
      _buildToolkit(),
    ]);
  }

  Widget _buildPhoto(double? height) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _border),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 30, offset: const Offset(0, 12), spreadRadius: -6)],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(fit: StackFit.expand, children: [
          Image.network(
            'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&q=80',
            fit: BoxFit.cover,
            loadingBuilder: (_, child, p) => p == null ? child : Container(color: _cardBg, child: Center(
              child: CircularProgressIndicator(strokeWidth: 1.5, color: _accent.withOpacity(0.4),
                  value: p.expectedTotalBytes != null ? p.cumulativeBytesLoaded / p.expectedTotalBytes! : null),
            )),
            errorBuilder: (_, __, ___) => Container(color: _cardBg, child: Icon(Icons.code_rounded, size: 40, color: _muted.withOpacity(0.3))),
          ),
          Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                colors: [Colors.transparent, Colors.transparent, _bg.withOpacity(0.85)], stops: const [0, 0.5, 1]),
          ))),
          Positioned(bottom: 18, left: 18, child: Row(children: [
            Container(width: 8, height: 8, decoration: BoxDecoration(color: _accent, shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: _accent.withOpacity(0.4), blurRadius: 8)])),
            const SizedBox(width: 10),
            Text('Available for projects', style: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w500, color: _heading.withOpacity(0.9))),
          ])),
        ]),
      ),
    );
  }

  Widget _buildToolkit() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('TOOLKIT', style: GoogleFonts.spaceMono(fontSize: 10, fontWeight: FontWeight.w500, letterSpacing: 2, color: _muted)),
      const SizedBox(height: 14),
      Wrap(spacing: 10, runSpacing: 10, children: const [
        _TechLogo(url: 'https://img.icons8.com/color/96/flutter.png', name: 'Flutter', color: Color(0xFF54C5F8)),
        _TechLogo(url: 'https://img.icons8.com/color/96/react-native.png', name: 'React Native', color: Color(0xFF61DAFB)),
        _TechLogo(url: 'https://img.icons8.com/color/96/firebase.png', name: 'Firebase', color: Color(0xFFFFCA28)),
        _TechLogo(url: 'https://img.icons8.com/color/96/dart.png', name: 'Dart', color: Color(0xFF0175C2)),
        _TechLogo(url: 'https://img.icons8.com/color/96/google-play.png', name: 'Play Store', color: Color(0xFF34A853)),
        _TechLogo(url: 'https://img.icons8.com/color/96/python--v1.png', name: 'AI / ML', color: Color(0xFFAB47BC)),
      ]),
    ]);
  }

  Widget _buildText(bool isMobile) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 28, height: 1.5, decoration: BoxDecoration(color: _accent.withOpacity(0.6), borderRadius: BorderRadius.circular(1))),
        const SizedBox(width: 12),
        Text('ABOUT ME', style: GoogleFonts.spaceMono(fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 3.5, color: _accent)),
      ]),
      const SizedBox(height: 28),
      RichText(text: TextSpan(
        style: GoogleFonts.syne(fontSize: isMobile ? 28 : 40, fontWeight: FontWeight.w800, height: 1.15, letterSpacing: isMobile ? -0.5 : -1.5, color: _heading),
        children: [
          const TextSpan(text: 'Flutter & React Native\nDeveloper from '),
          TextSpan(text: 'Pakistan', style: TextStyle(color: _accent, decoration: TextDecoration.underline,
              decorationColor: _accent.withOpacity(0.3), decorationThickness: 2)),
        ],
      )),
      const SizedBox(height: 28),
      ...[AppStrings.aboutBody1, AppStrings.aboutBody2, AppStrings.aboutBody3].expand((t) => [
        Text(t, style: GoogleFonts.inter(fontSize: 15, fontWeight: FontWeight.w300, height: 1.85, color: _body)),
      ]),
      const SizedBox(height: 22),
      Container(width: 56, height: 1, color: _border),
      const SizedBox(height: 10),
      Text('LANGUAGES', style: GoogleFonts.spaceMono(fontSize: 10, fontWeight: FontWeight.w500, letterSpacing: 2, color: _muted)),
      const SizedBox(height: 14),
      Wrap(spacing: 10, runSpacing: 10, children: const [
        _LangChip(flagUrl: 'https://flagcdn.com/w80/pk.png', lang: 'Urdu', level: 'Native'),
        _LangChip(flagUrl: 'https://flagcdn.com/w80/gb.png', lang: 'English', level: 'Fluent'),
        _LangChip(flagUrl: 'https://flagcdn.com/w80/af.png', lang: 'Pashto', level: 'Native'),
      ]),
    ]);
  }
}

// ── Chips ────────────────────────────────────────────────────

class _LangChip extends StatelessWidget {
  final String flagUrl, lang, level;
  const _LangChip({required this.flagUrl, required this.lang, required this.level});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF2A2A3E)), color: const Color(0xFF1A1A2E)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        ClipRRect(borderRadius: BorderRadius.circular(3), child: Image.network(flagUrl, width: 24, height: 16, fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(width: 24, height: 16, color: const Color(0xFF2A2A3E), child: const Icon(Icons.flag, size: 12, color: Color(0xFF787878))))),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(lang, style: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w600, color: const Color(0xFFE8E8E8), height: 1)),
          const SizedBox(height: 3),
          Text(level, style: GoogleFonts.inter(fontSize: 9, fontWeight: FontWeight.w400, color: const Color(0xFF787878), height: 1)),
        ]),
      ]),
    );
  }
}

class _TechLogo extends StatefulWidget {
  final String url, name;
  final Color color;
  const _TechLogo({required this.url, required this.name, required this.color});
  @override State<_TechLogo> createState() => _TechLogoState();
}

class _TechLogoState extends State<_TechLogo> {
  bool _h = false;
  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _h = true),
      onExit: (_) => setState(() => _h = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: _h ? widget.color.withOpacity(0.1) : const Color(0xFF1A1A2E),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _h ? widget.color.withOpacity(0.35) : const Color(0xFF2A2A3E)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Image.network(widget.url, width: 24, height: 24, fit: BoxFit.contain,
              errorBuilder: (_, __, ___) => Icon(Icons.code, size: 22, color: widget.color.withOpacity(0.7))),
          const SizedBox(width: 10),
          Text(widget.name, style: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w600, color: const Color(0xFFE8E8E8))),
        ]),
      ),
    );
  }
}

// ── Floating Card ───────────────────────────────────────────

class _FloatingCard extends StatefulWidget {
  final String imageUrl, title, subtitle;
  const _FloatingCard({required this.imageUrl, required this.title, required this.subtitle});
  @override State<_FloatingCard> createState() => _FloatingCardState();
}

class _FloatingCardState extends State<_FloatingCard> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  @override void initState() { super.initState(); _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 3400))..repeat(reverse: true); }
  @override void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(animation: CurvedAnimation(parent: _c, curve: Curves.easeInOut),
      builder: (_, child) => Transform.translate(offset: Offset(0, -8 * _c.value), child: child),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        decoration: BoxDecoration(color: const Color(0xFF1A1A2E), borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFF2A2A3E)),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 28, offset: const Offset(0, 10), spreadRadius: -4)]),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 40,
              decoration: BoxDecoration(color: const Color(0xFF58E6A0).withOpacity(0.1), borderRadius: BorderRadius.circular(11)),
              child: Center(child: Image.network(widget.imageUrl, width: 24, height: 24, fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => Icon(Icons.rocket_launch, size: 20, color: const Color(0xFF58E6A0).withOpacity(0.7))))),
          const SizedBox(width: 14),
          Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Text(widget.title, style: GoogleFonts.syne(fontSize: 15, fontWeight: FontWeight.w700, color: const Color(0xFFE8E8E8))),
            const SizedBox(height: 5),
            Text(widget.subtitle, style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w400, color: const Color(0xFF787878))),
          ]),
        ]),
      ),
    );
  }
}